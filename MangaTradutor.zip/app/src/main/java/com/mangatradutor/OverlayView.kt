package com.mangatradutor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

class OverlayView(ctx: Context) : View(ctx) {
    private var items: List<Item> = emptyList()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    fun setItems(list: List<Item>) {
        items = list
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        for (item in items) {
            paint.color = item.bg
            for (r in item.covers) canvas.drawRoundRect(r, 6f, 6f, paint)
            canvas.save()
            canvas.translate(item.tx, item.ty)
            item.layout.draw(canvas)
            canvas.restore()
        }
    }
}
