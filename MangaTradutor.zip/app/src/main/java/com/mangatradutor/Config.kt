package com.mangatradutor

import android.content.Context

object Config {
    private fun p(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    /** 0 = automático, 1 = japonês, 2 = coreano, 3 = chinês, 4 = inglês */
    fun modo(c: Context): Int = p(c).getInt("modo", 0)
    fun setModo(c: Context, v: Int) = p(c).edit().putInt("modo", v).apply()

    fun online(c: Context): Boolean = p(c).getBoolean("online", true)
    fun setOnline(c: Context, v: Boolean) = p(c).edit().putBoolean("online", v).apply()

    fun apiKey(c: Context): String = p(c).getString("apikey", "") ?: ""
    fun setApiKey(c: Context, v: String) = p(c).edit().putString("apikey", v).apply()
}
