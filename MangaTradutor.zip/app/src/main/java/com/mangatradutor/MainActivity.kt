package com.mangatradutor

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class MainActivity : Activity() {

    private val scope = CoroutineScope(Dispatchers.Main)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        val title = TextView(this).apply {
            text = "Manga Tradutor"
            textSize = 26f
            gravity = Gravity.START
        }
        val info = TextView(this).apply {
            text = getString(R.string.instrucoes)
            textSize = 16f
            setPadding(0, pad / 2, 0, pad / 2)
        }
        val btnDownload = Button(this).apply {
            text = "Baixar idiomas (use Wi-Fi)"
            setOnClickListener { baixarIdiomas(this) }
        }
        val btnAtivar = Button(this).apply {
            text = "Ativar tradução"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        root.addView(title)
        root.addView(info)
        root.addView(btnDownload)
        root.addView(btnAtivar)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun baixarIdiomas(btn: Button) {
        btn.isEnabled = false
        Toast.makeText(this, "Baixando... pode demorar alguns minutos", Toast.LENGTH_LONG).show()
        scope.launch {
            var ok = 0
            val langs = listOf(
                TranslateLanguage.JAPANESE, TranslateLanguage.KOREAN,
                TranslateLanguage.CHINESE, TranslateLanguage.ENGLISH,
                TranslateLanguage.SPANISH, TranslateLanguage.FRENCH,
                TranslateLanguage.INDONESIAN, TranslateLanguage.THAI,
                TranslateLanguage.VIETNAMESE, TranslateLanguage.RUSSIAN
            )
            for (l in langs) {
                try {
                    val t = Translation.getClient(
                        TranslatorOptions.Builder()
                            .setSourceLanguage(l)
                            .setTargetLanguage(TranslateLanguage.PORTUGUESE)
                            .build()
                    )
                    t.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
                    t.close()
                    ok++
                } catch (e: Exception) {
                }
            }
            Toast.makeText(this@MainActivity, "Idiomas prontos: $ok/${langs.size}", Toast.LENGTH_LONG).show()
            btn.isEnabled = true
        }
    }
}
