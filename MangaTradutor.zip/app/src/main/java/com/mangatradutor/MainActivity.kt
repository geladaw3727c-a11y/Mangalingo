package com.mangatradutor

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class MainActivity : Activity() {

    private val scope = CoroutineScope(Dispatchers.Main)
    private lateinit var btnToggle: Button
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()
        val gap = (10 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        fun space() = android.view.View(this).apply {
            layoutParams = LinearLayout.LayoutParams(1, gap)
        }

        root.addView(TextView(this).apply { text = "Manga Tradutor"; textSize = 26f })

        status = TextView(this).apply { textSize = 16f; setPadding(0, gap, 0, gap) }
        root.addView(status)

        btnToggle = Button(this).apply {
            textSize = 18f
            setOnClickListener { alternar() }
        }
        root.addView(btnToggle)
        root.addView(space())

        root.addView(TextView(this).apply {
            text = "Idioma do mangá (escolher um deixa MUITO mais rápido):"
            textSize = 15f
        })
        val group = RadioGroup(this)
        val nomes = listOf(
            "Automático (mais lento)", "Japonês (mangá)", "Coreano (manhwa)",
            "Chinês (manhua)", "Inglês"
        )
        nomes.forEachIndexed { i, n ->
            group.addView(RadioButton(this).apply { id = 100 + i; text = n })
        }
        group.check(100 + Config.modo(this))
        group.setOnCheckedChangeListener { _, id -> Config.setModo(this, id - 100) }
        root.addView(group)
        root.addView(space())

        root.addView(Switch(this).apply {
            text = "Tradução online (mais precisa, usa internet)"
            isChecked = Config.online(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Config.setOnline(this@MainActivity, v) }
        })
        root.addView(space())

        root.addView(Button(this).apply {
            text = "Ligar serviço de acessibilidade (só na 1ª vez)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "Baixar idiomas offline (use Wi-Fi)"
            setOnClickListener { baixarIdiomas(this) }
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        atualizar()
    }

    private fun alternar() {
        if (TranslatorService.instance == null) {
            Toast.makeText(this, "Ligue o serviço \"Manga Tradutor\" na acessibilidade", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        TranslatorService.ativo = !TranslatorService.ativo
        atualizar()
        if (TranslatorService.ativo) {
            Toast.makeText(this, "Ativada! Abra seu leitor de mangá.", Toast.LENGTH_LONG).show()
        }
    }

    private fun atualizar() {
        val ligado = TranslatorService.instance != null
        val on = ligado && TranslatorService.ativo
        btnToggle.text = if (on) "⏹ DESATIVAR tradução" else "▶ ATIVAR tradução"
        status.text = when {
            !ligado -> "Serviço de acessibilidade desligado. Toque em \"Ligar serviço\" (só uma vez)."
            on -> "Tradução ATIVADA. Abra o leitor de mangá. Volte aqui para desativar."
            else -> "Tradução desativada."
        }
    }

    private fun baixarIdiomas(btn: Button) {
        btn.isEnabled = false
        Toast.makeText(this, "Baixando... pode demorar alguns minutos", Toast.LENGTH_LONG).show()
        scope.launch {
            var ok = 0
            val langs = listOf(
                TranslateLanguage.JAPANESE, TranslateLanguage.KOREAN,
                TranslateLanguage.CHINESE, TranslateLanguage.ENGLISH,
                TranslateLanguage.SPANISH, TranslateLanguage.FRENCH,
                TranslateLanguage.INDONESIAN, TranslateLanguage.THAI,
                TranslateLanguage.VIETNAMESE, TranslateLanguage.RUSSIAN
            )
            for (l in langs) {
                try {
                    val t = Translation.getClient(
                        TranslatorOptions.Builder()
                            .setSourceLanguage(l)
                            .setTargetLanguage(TranslateLanguage.PORTUGUESE)
                            .build()
                    )
                    t.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
                    t.close()
                    ok++
                } catch (e: Exception) {
                }
            }
            Toast.makeText(this@MainActivity, "Idiomas prontos: $ok/${langs.size}", Toast.LENGTH_LONG).show()
            btn.isEnabled = true
        }
    }
}
