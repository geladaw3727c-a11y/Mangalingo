package com.mangatradutor

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors
import kotlin.coroutines.resume
import kotlin.math.abs

class TranslatorService : AccessibilityService() {

    companion object {
        /** Liga/desliga a tradução (controlado pelo botão do app). */
        @Volatile var ativo = false
        @Volatile var instance: TranslatorService? = null
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val exec = Executors.newSingleThreadExecutor()
    private lateinit var engine: TranslationEngine
    private lateinit var wm: WindowManager
    private var overlay: OverlayView? = null
    private var job: Job? = null
    private var density = 2f

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        density = resources.displayMetrics.density
        engine = TranslationEngine(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addOverlay()
        startLoop()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        ativo = false
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        ativo = false
        job?.cancel()
        scope.cancel()
        try { overlay?.let { wm.removeView(it) } } catch (e: Exception) {}
        try { engine.close() } catch (e: Exception) {}
        exec.shutdown()
        super.onDestroy()
    }

    private fun addOverlay() {
        val v = OverlayView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.layoutInDisplayCutoutMode =
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        wm.addView(v, lp)
        overlay = v
    }

    private suspend fun ui(block: () -> Unit) = withContext(Dispatchers.Main) { block() }

    private fun startLoop() {
        job = scope.launch {
            var last: IntArray? = null
            var stable = 0
            var done = false
            var shown = false
            while (isActive) {
                if (!ativo) {
                    // Desativado pelo app: limpa a tela e não captura nada.
                    if (shown) { ui { overlay?.setItems(emptyList()) }; shown = false }
                    last = null; done = false; stable = 0
                    delay(600)
                    continue
                }
                delay(300)
                val bmp = shot()
                if (bmp == null) { delay(900); continue }
                val sig = signature(bmp)
                val prev = last
                val changed = prev == null || differs(sig, prev)
                last = sig

                if (changed) {
                    stable = 0; done = false
                    if (shown) { ui { overlay?.setItems(emptyList()) }; shown = false }
                } else {
                    stable++
                }

                if (!done && stable >= 1) {
                    done = true
                    val items = try { engine.process(bmp, density) } catch (e: Exception) { emptyList() }
                    if (items.isNotEmpty() && ativo) {
                        val chk = shot()
                        if (chk != null && differs(signature(chk), sig)) {
                            last = signature(chk); stable = 0; done = false
                            chk.recycle()
                        } else {
                            chk?.recycle()
                            val w = bmp.width; val h = bmp.height
                            ui { show(items, w, h) }
                            shown = true
                            delay(300)
                            val b2 = shot()
                            if (b2 != null) { last = signature(b2); b2.recycle() }
                        }
                    }
                }
                bmp.recycle()
            }
        }
    }

    private fun show(items: List<Item>, w: Int, h: Int) {
        val v = overlay ?: return
        val lp = v.layoutParams as WindowManager.LayoutParams
        if (lp.width != w || lp.height != h) {
            lp.width = w; lp.height = h
            wm.updateViewLayout(v, lp)
        }
        v.setItems(items)
    }

    private suspend fun shot(): Bitmap? = suspendCancellableCoroutine { c ->
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, exec, object : TakeScreenshotCallback {
                override fun onSuccess(r: ScreenshotResult) {
                    val hb = r.hardwareBuffer
                    var sw: Bitmap? = null
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                        sw = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        hw?.recycle()
                    } catch (e: Exception) {
                    } finally {
                        hb.close()
                    }
                    if (c.isActive) c.resume(sw)
                }

                override fun onFailure(errorCode: Int) {
                    if (c.isActive) c.resume(null)
                }
            })
        } catch (e: Exception) {
            if (c.isActive) c.resume(null)
        }
    }

    private fun signature(b: Bitmap): IntArray {
        val gw = 48; val gh = 96
        val a = IntArray(gw * gh)
        for (y in 0 until gh) for (x in 0 until gw) {
            val px = (x * b.width / gw + b.width / (2 * gw)).coerceAtMost(b.width - 1)
            val py = (y * b.height / gh + b.height / (2 * gh)).coerceAtMost(b.height - 1)
            val p = b.getPixel(px, py)
            a[y * gw + x] = (((p shr 16) and 255) * 3 + ((p shr 8) and 255) * 6 + (p and 255)) / 10
        }
        return a
    }

    private fun differs(a: IntArray, b: IntArray): Boolean {
        var n = 0
        val start = 4 * 48
        for (i in start until a.size) if (abs(a[i] - b[i]) > 30) n++
        return n > a.size * 0.015
    }
}
