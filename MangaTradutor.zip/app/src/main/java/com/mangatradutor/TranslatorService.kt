package com.mangatradutor

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors
import kotlin.coroutines.resume
import kotlin.math.abs

class TranslatorService : AccessibilityService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val exec = Executors.newSingleThreadExecutor()
    private val engine = TranslationEngine()
    private lateinit var wm: WindowManager
    private var overlay: OverlayView? = null
    private var fab: TextView? = null
    private var job: Job? = null
    @Volatile private var paused = false
    private var density = 2f

    override fun onServiceConnected() {
        super.onServiceConnected()
        density = resources.displayMetrics.density
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addOverlay()
        addFab()
        startLoop()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        job?.cancel()
        scope.cancel()
        try { overlay?.let { wm.removeView(it) } } catch (e: Exception) {}
        try { fab?.let { wm.removeView(it) } } catch (e: Exception) {}
        engine.close()
        exec.shutdown()
        super.onDestroy()
    }

    // ---------- janelas ----------

    private fun addOverlay() {
        val v = OverlayView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.layoutInDisplayCutoutMode =
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        wm.addView(v, lp)
        overlay = v
    }

    private fun addFab() {
        val size = (44 * density).toInt()
        val tv = TextView(this).apply {
            text = "🌐"
            textSize = 20f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(150, 0, 0, 0))
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (8 * density).toInt()
        lp.y = (300 * density).toInt()

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        var downTime = 0L; var moved = false
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = lp.x; startY = lp.y
                    downTime = System.currentTimeMillis(); moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt(); lp.y = startY + dy.toInt()
                        wm.updateViewLayout(tv, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    if (System.currentTimeMillis() - downTime > 800) {
                        Toast.makeText(this, "Tradução desligada", Toast.LENGTH_SHORT).show()
                        disableSelf()
                    } else {
                        paused = !paused
                        tv.text = if (paused) "⏸" else "🌐"
                    }
                }
            }
            true
        }
        wm.addView(tv, lp)
        fab = tv
    }

    // ---------- laço principal ----------

    private suspend fun ui(block: () -> Unit) = withContext(Dispatchers.Main) { block() }

    private fun startLoop() {
        job = scope.launch {
            var last: IntArray? = null
            var stable = 0
            var done = false
            var shown = false
            while (isActive) {
                delay(450)
                if (paused) {
                    if (shown) { ui { overlay?.setItems(emptyList()) }; shown = false }
                    last = null; done = false
                    continue
                }
                val bmp = shot()
                if (bmp == null) { delay(900); continue }
                val sig = signature(bmp)
                val prev = last
                val changed = prev == null || differs(sig, prev)
                last = sig

                if (changed) {
                    // A página mudou (rolagem/troca): some com a tradução antiga.
                    stable = 0; done = false
                    if (shown) { ui { overlay?.setItems(emptyList()) }; shown = false }
                } else {
                    stable++
                }

                if (!done && stable >= 1) {
                    done = true
                    val items = try { engine.process(bmp, density) } catch (e: Exception) { emptyList() }
                    if (items.isNotEmpty()) {
                        val chk = shot()
                        if (chk != null && differs(signature(chk), sig)) {
                            // O usuário rolou durante a tradução: descarta e tenta de novo.
                            last = signature(chk); stable = 0; done = false
                            chk.recycle()
                        } else {
                            chk?.recycle()
                            val w = bmp.width; val h = bmp.height
                            ui { show(items, w, h) }
                            shown = true
                            delay(350)
                            val b2 = shot()
                            if (b2 != null) { last = signature(b2); b2.recycle() }
                        }
                    }
                }
                bmp.recycle()
            }
        }
    }

    private fun show(items: List<Item>, w: Int, h: Int) {
        val v = overlay ?: return
        val lp = v.layoutParams as WindowManager.LayoutParams
        if (lp.width != w || lp.height != h) {
            lp.width = w; lp.height = h
            wm.updateViewLayout(v, lp)
        }
        v.setItems(items)
    }

    // ---------- captura de tela (permissão única de acessibilidade) ----------

    private suspend fun shot(): Bitmap? = suspendCancellableCoroutine { c ->
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, exec, object : TakeScreenshotCallback {
                override fun onSuccess(r: ScreenshotResult) {
                    val hb = r.hardwareBuffer
                    var sw: Bitmap? = null
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                        sw = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        hw?.recycle()
                    } catch (e: Exception) {
                    } finally {
                        hb.close()
                    }
                    if (c.isActive) c.resume(sw)
                }

                override fun onFailure(errorCode: Int) {
                    if (c.isActive) c.resume(null)
                }
            })
        } catch (e: Exception) {
            if (c.isActive) c.resume(null)
        }
    }

    /** Miniatura em tons de cinza (48x96) para detectar rolagem/mudança de página. */
    private fun signature(b: Bitmap): IntArray {
        val gw = 48; val gh = 96
        val a = IntArray(gw * gh)
        for (y in 0 until gh) for (x in 0 until gw) {
            val px = (x * b.width / gw + b.width / (2 * gw)).coerceAtMost(b.width - 1)
            val py = (y * b.height / gh + b.height / (2 * gh)).coerceAtMost(b.height - 1)
            val p = b.getPixel(px, py)
            a[y * gw + x] = (((p shr 16) and 255) * 3 + ((p shr 8) and 255) * 6 + (p and 255)) / 10
        }
        return a
    }

    private fun differs(a: IntArray, b: IntArray): Boolean {
        var n = 0
        val start = 4 * 48 // ignora a barra de status (relógio muda sempre)
        for (i in start until a.size) if (abs(a[i] - b[i]) > 30) n++
        return n > a.size * 0.015
    }
}
