package com.mangatradutor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Uma fala já traduzida: retângulos de fundo + texto pronto para desenhar. */
class Item(
    val covers: List<RectF>,
    val bg: Int,
    val layout: StaticLayout,
    val tx: Float,
    val ty: Float
)

class TranslationEngine(private val ctx: Context) {

    private class Cand(val box: Rect, val raw: String, val lines: Int, val score: Int)
    private class Group(val box: Rect, val raw: String, val lines: Int, val bg: Int, val balloon: Rect?)
    private class Plan(val g: Group, val text: String, val cont: RectF)

    private val latin: TextRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val ja: TextRecognizer = TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
    private val ko: TextRecognizer = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
    private val zh: TextRecognizer = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
    private val langId = LanguageIdentification.getClient()
    private val translators = HashMap<String, Translator>()
    private val mlMutex = Mutex()
    private val cache = ConcurrentHashMap<String, String>()

    fun close() {
        latin.close(); ja.close(); ko.close(); zh.close(); langId.close()
        translators.values.forEach { it.close() }
    }

    suspend fun process(bmp: Bitmap, density: Float): List<Item> = coroutineScope {
        // OCR numa versão menor da imagem (mais rápido); as caixas voltam para o tamanho real.
        val f = if (bmp.width > 1080) 1080f / bmp.width else 1f
        val ocrBmp = if (f < 1f) Bitmap.createScaledBitmap(bmp, 1080, (bmp.height * f).toInt(), true) else bmp
        val inv = 1f / f
        val img = InputImage.fromBitmap(ocrBmp, 0)

        val kinds = when (Config.modo(ctx)) {
            1 -> listOf(1)
            2 -> listOf(2)
            3 -> listOf(3)
            4 -> listOf(0)
            else -> listOf(0, 1, 2, 3)
        }

        val all: List<Cand> = kinds.map { kind ->
            async {
                try {
                    val rec = when (kind) { 0 -> latin; 1 -> ja; 2 -> ko; else -> zh }
                    val out = ArrayList<Cand>()
                    for (b in rec.process(img).await().textBlocks) {
                        val bb = b.boundingBox ?: continue
                        val s = score(kind, b.text)
                        if (s > 0) {
                            val box = Rect(
                                (bb.left * inv).toInt(), (bb.top * inv).toInt(),
                                (bb.right * inv).toInt(), (bb.bottom * inv).toInt()
                            )
                            out.add(Cand(box, b.text, max(1, b.lines.size), s))
                        }
                    }
                    out
                } catch (e: Exception) {
                    ArrayList<Cand>()
                }
            }
        }.awaitAll().flatten()
        if (ocrBmp !== bmp) ocrBmp.recycle()

        // Remove duplicatas entre reconhecedores.
        val kept = ArrayList<Cand>()
        for (c in all.sortedByDescending { it.score }) {
            if (kept.none { overlaps(it.box, c.box) }) kept.add(c)
        }

        // Junta pedaços do mesmo balão (mais contexto = tradução melhor).
        val sorted = kept.sortedWith(compareBy({ it.box.top }, { it.box.left }))
        val used = BooleanArray(sorted.size)
        val groups = ArrayList<Group>()
        for (i in sorted.indices) {
            if (used[i]) continue
            used[i] = true
            val c = sorted[i]
            val (bg, frac) = sampleBg(bmp, c.box, padOf(c.box).toInt())
            val bl = balloon(bmp, c.box, bg)
            if (bl == null && frac < 0.6f) continue // efeito sonoro/texto sobre arte: deixa como está
            val box = Rect(c.box)
            val parts = arrayListOf(c)
            if (bl != null) {
                for (j in i + 1 until sorted.size) {
                    if (used[j]) continue
                    val o = sorted[j]
                    if (bl.contains(o.box.centerX(), o.box.centerY())) {
                        used[j] = true
                        parts.add(o)
                        box.union(o.box)
                    }
                }
            }
            groups.add(Group(box, join(parts.map { it.raw }), parts.sumOf { it.lines }, bg, bl))
        }

        val translated: List<String?> = groups.map { g ->
            async {
                try {
                    if (g.raw.length < 2) null
                    else {
                        val src = detect(g.raw)
                        if (src == "pt") null else translate(g.raw, src)
                    }
                } catch (e: Exception) {
                    null
                }
            }
        }.awaitAll()

        val plans = ArrayList<Plan>()
        for ((i, g) in groups.withIndex()) {
            val t = translated[i] ?: continue
            plans.add(Plan(g, t, contOf(bmp, g)))
        }
        resolveOverlaps(plans.map { it.cont })

        val result = ArrayList<Item>()
        for (p in plans) {
            try { result.add(render(bmp, p, density)) } catch (e: Exception) {}
        }
        result
    }

    // ---------- idioma ----------

    private fun counts(t: String): IntArray {
        var kana = 0; var hang = 0; var han = 0; var lat = 0
        for (ch in t) {
            when {
                ch in '\u3040'..'\u30FF' -> kana++
                ch in '\uAC00'..'\uD7AF' || ch in '\u1100'..'\u11FF' -> hang++
                ch in '\u4E00'..'\u9FFF' -> han++
                ch.isLetter() && ch.code < 0x250 -> lat++
            }
        }
        return intArrayOf(kana, hang, han, lat)
    }

    private fun join(parts: List<String>): String {
        val c = counts(parts.joinToString(""))
        val cjk = c[0] + c[1] + c[2] > c[3]
        return parts.joinToString(if (cjk) "" else " ") {
            if (cjk) it.replace("\n", "") else it.replace("-\n", "").replace("\n", " ")
        }.trim()
    }

    private suspend fun identify(text: String): String =
        langId.identifyLanguage(text).await().substringBefore('-')

    private suspend fun detect(text: String): String {
        val (kana, hang, han, lat) = counts(text)
        return when {
            kana > 0 -> "ja"
            hang > 0 -> "ko"
            han > 0 && lat == 0 -> {
                val id = identify(text)
                if (id == "ja" || id == "zh") id else "zh"
            }
            else -> identify(text).let { if (it == "und") "en" else it }
        }
    }

    private fun score(kind: Int, t: String): Int {
        val (kana, hang, han, lat) = counts(t)
        val total = kana + hang + han + lat
        if (total < 2) return 0
        return when (kind) {
            0 -> if (lat >= total * 0.8) lat else 0
            1 -> if (kana > 0 || (han > 0 && lat == 0 && hang == 0)) kana + han else 0
            2 -> if (hang >= total * 0.5) hang else 0
            else -> if (han >= total * 0.8 && kana == 0) han else 0
        }
    }

    private fun overlaps(a: Rect, b: Rect): Boolean {
        val l = max(a.left, b.left); val r = min(a.right, b.right)
        val t = max(a.top, b.top); val bt = min(a.bottom, b.bottom)
        if (r <= l || bt <= t) return false
        val inter = (r - l).toLong() * (bt - t)
        val minArea = min(a.width().toLong() * a.height(), b.width().toLong() * b.height())
        return minArea > 0 && inter > minArea * 0.3
    }

    // ---------- tradução ----------

    private suspend fun translate(text: String, src: String): String? {
        val key = "$src|$text"
        cache[key]?.let { return it }
        var out: String? = null
        if (Config.online(ctx)) out = translateOnline(text, src)
        if (out == null) out = translateOffline(text, src)
        if (out != null) {
            if (cache.size > 500) cache.clear()
            cache[key] = out
        }
        return out
    }

    /** Tradução online do Google (mais precisa). Se falhar, cai para a offline. */
    private suspend fun translateOnline(text: String, src: String): String? = withContext(Dispatchers.IO) {
        try {
            val sl = if (src == "zh") "zh-CN" else src
            val url = URL(
                "https://translate.googleapis.com/translate_a/single?client=gtx&sl=" + sl +
                        "&tl=pt&dt=t&q=" + URLEncoder.encode(text, "UTF-8")
            )
            val c = url.openConnection() as HttpURLConnection
            c.connectTimeout = 4000
            c.readTimeout = 6000
            c.setRequestProperty("User-Agent", "Mozilla/5.0")
            if (c.responseCode != 200) return@withContext null
            val body = c.inputStream.bufferedReader().use { it.readText() }
            val arr = JSONArray(body).getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until arr.length()) sb.append(arr.getJSONArray(i).optString(0, ""))
            val s = sb.toString().trim()
            if (s.isEmpty()) null else s
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun translateOffline(text: String, src: String): String? = mlMutex.withLock {
        val lang = TranslateLanguage.fromLanguageTag(src) ?: return@withLock null
        val tr = translators.getOrPut(src) {
            Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(lang)
                    .setTargetLanguage(TranslateLanguage.PORTUGUESE)
                    .build()
            )
        }
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
        tr.translate(text).await()
    }

    // ---------- desenho ----------

    private fun padOf(box: Rect): Float = max(6f, min(box.width(), box.height()) * 0.08f)

    /** Área onde o texto traduzido pode ficar: o interior do balão (encolhido p/ balão oval). */
    private fun contOf(bmp: Bitmap, g: Group): RectF {
        val sw = bmp.width.toFloat()
        val sh = bmp.height.toFloat()
        val bl = g.balloon
        if (bl != null) {
            val bw = bl.width(); val bh = bl.height()
            return RectF(
                bl.exactCenterX() - bw * 0.4f, bl.exactCenterY() - bh * 0.4f,
                bl.exactCenterX() + bw * 0.4f, bl.exactCenterY() + bh * 0.4f
            )
        }
        val pad = padOf(g.box)
        val l = g.box.left - pad; val t = g.box.top - pad
        val r = g.box.right + pad; val bt = g.box.bottom + pad
        val ex = (r - l) * 0.12f
        val ey = (bt - t) * 0.10f
        return RectF(max(0f, l - ex), max(0f, t - ey), min(sw, r + ex), min(sh, bt + ey))
    }

    /** Garante que nenhuma tradução fique em cima de outra: recorta as áreas que se cruzam. */
    private fun resolveOverlaps(conts: List<RectF>) {
        for (i in conts.indices) for (j in i + 1 until conts.size) {
            val a = conts[i]; val b = conts[j]
            if (!RectF.intersects(a, b)) continue
            val ox = min(a.right, b.right) - max(a.left, b.left)
            val oy = min(a.bottom, b.bottom) - max(a.top, b.top)
            if (oy <= ox) {
                if (a.centerY() <= b.centerY()) { a.bottom -= oy / 2f + 1f; b.top += oy / 2f + 1f }
                else { b.bottom -= oy / 2f + 1f; a.top += oy / 2f + 1f }
            } else {
                if (a.centerX() <= b.centerX()) { a.right -= ox / 2f + 1f; b.left += ox / 2f + 1f }
                else { b.right -= ox / 2f + 1f; a.left += ox / 2f + 1f }
            }
        }
    }

    private fun render(bmp: Bitmap, p: Plan, d: Float): Item {
        val sw = bmp.width.toFloat()
        val sh = bmp.height.toFloat()
        val g = p.g
        val box = g.box
        val cont = p.cont
        val text = p.text
        val pad = padOf(box)
        val inner = 3f * d

        val bg = g.bg
        val lum = 0.299 * Color.red(bg) + 0.587 * Color.green(bg) + 0.114 * Color.blue(bg)
        val fg = if (lum > 140) Color.rgb(17, 17, 17) else Color.rgb(242, 242, 242)

        val boxInfl = RectF(
            max(0f, box.left - pad), max(0f, box.top - pad),
            min(sw, box.right + pad), min(sh, box.bottom + pad)
        )

        val contW = max(16f, cont.width() - 2 * inner)
        val contH = max(16f, cont.height() - 2 * inner)

        // Tamanho parecido com o original (levemente maior se for pequeno) e sempre encolhe até caber.
        val origPx = box.height().toFloat() / g.lines * 0.8f
        val floor = 6f * d
        var size = (origPx * 1.1f).coerceIn(9.5f * d, 22f * d)

        val paint = TextPaint(TextPaint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            color = fg
        }
        fun lay(sz: Float): StaticLayout {
            paint.textSize = sz
            return StaticLayout.Builder
                .obtain(text, 0, text.length, paint, contW.toInt())
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setIncludePad(false)
                .setLineSpacing(0f, 0.95f)
                .setBreakStrategy(Layout.BREAK_STRATEGY_BALANCED)
                .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NORMAL)
                .build()
        }
        var layout = lay(size)
        while (size > floor && layout.height > contH) {
            size -= 0.5f * d
            layout = lay(size)
        }

        val cx = cont.centerX()
        val cy = cont.centerY()
        val tx = cx - contW / 2f
        val ty = (cy - layout.height / 2f).coerceIn(0f, max(0f, sh - layout.height))

        // Dentro de um balão o fundo já é da cor certa: só apaga o texto original.
        if (g.balloon != null) return Item(listOf(boxInfl), bg, layout, tx, ty)

        var maxLine = 0f
        for (i in 0 until layout.lineCount) maxLine = max(maxLine, layout.getLineWidth(i))
        val rw = maxLine + 2 * inner
        val rh = layout.height + 2 * inner
        val textRect = RectF(cx - rw / 2f, ty - inner, cx + rw / 2f, ty - inner + rh)
        return Item(listOf(boxInfl, textRect), bg, layout, tx, ty)
    }

    /** Cor mais comum num anel ao redor da fala (= cor do balão). */
    private fun sampleBg(b: Bitmap, box: Rect, pad: Int): Pair<Int, Float> {
        val x0 = (box.left - pad).coerceIn(0, b.width - 1)
        val x1 = (box.right + pad).coerceIn(0, b.width - 1)
        val y0 = (box.top - pad).coerceIn(0, b.height - 1)
        val y1 = (box.bottom + pad).coerceIn(0, b.height - 1)
        val map = HashMap<Int, LongArray>()
        fun add(x: Int, y: Int) {
            val p = b.getPixel(x, y)
            val k = (((p shr 20) and 15) shl 8) or (((p shr 12) and 15) shl 4) or ((p shr 4) and 15)
            val a = map.getOrPut(k) { LongArray(4) }
            a[0] += 1L
            a[1] += ((p shr 16) and 255).toLong()
            a[2] += ((p shr 8) and 255).toLong()
            a[3] += (p and 255).toLong()
        }
        val sx = max(1, (x1 - x0) / 40)
        val sy = max(1, (y1 - y0) / 40)
        var x = x0
        while (x <= x1) { add(x, y0); add(x, y1); x += sx }
        var y = y0
        while (y <= y1) { add(x0, y); add(x1, y); y += sy }
        val best = map.values.maxByOrNull { it[0] } ?: return Pair(Color.WHITE, 0f)
        val total = map.values.sumOf { it[0] }
        val color = Color.rgb((best[1] / best[0]).toInt(), (best[2] / best[0]).toInt(), (best[3] / best[0]).toInt())
        return Pair(color, best[0].toFloat() / total.toFloat())
    }

    /**
     * Acha o interior do balão: espalha a cor do fundo a partir da fala até bater na borda.
     * Ignora o "rabinho" do balão. Devolve null se vazar (fala solta sobre o desenho).
     */
    private fun balloon(b: Bitmap, box: Rect, bg: Int): Rect? {
        val st = 4
        val mx = (max(box.width(), box.height()) * 1.5f).toInt() + 60
        val x0 = (box.left - mx).coerceAtLeast(0)
        val x1 = (box.right + mx).coerceAtMost(b.width - 1)
        val y0 = (box.top - mx).coerceAtLeast(0)
        val y1 = (box.bottom + mx).coerceAtMost(b.height - 1)
        val gw = (x1 - x0) / st + 1
        val gh = (y1 - y0) / st + 1
        if (gw < 3 || gh < 3) return null
        val vis = BooleanArray(gw * gh)
        val q = IntArray(gw * gh)
        var qh = 0
        var qt = 0
        val br = Color.red(bg); val bgc = Color.green(bg); val bb = Color.blue(bg)

        fun sim(gx: Int, gy: Int): Boolean {
            val p = b.getPixel(x0 + gx * st, y0 + gy * st)
            return abs(Color.red(p) - br) + abs(Color.green(p) - bgc) + abs(Color.blue(p) - bb) < 70
        }
        fun seed(gx: Int, gy: Int) {
            if (gx < 0 || gy < 0 || gx >= gw || gy >= gh) return
            val i = gy * gw + gx
            if (!vis[i] && sim(gx, gy)) { vis[i] = true; q[qt++] = i }
        }

        val rx0 = (box.left - 6 - x0) / st
        val rx1 = (box.right + 6 - x0) / st
        val ry0 = (box.top - 6 - y0) / st
        val ry1 = (box.bottom + 6 - y0) / st
        for (gx in rx0..rx1) { seed(gx, ry0); seed(gx, ry1) }
        for (gy in ry0..ry1) { seed(rx0, gy); seed(rx1, gy) }

        val rowC = IntArray(gh)
        val colC = IntArray(gw)
        var border = 0
        var total = 0
        while (qh < qt) {
            val i = q[qh++]
            val gx = i % gw
            val gy = i / gw
            rowC[gy]++; colC[gx]++; total++
            if (gx == 0 || gy == 0 || gx == gw - 1 || gy == gh - 1) border++
            seed(gx + 1, gy); seed(gx - 1, gy); seed(gx, gy + 1); seed(gx, gy - 1)
        }
        // Muito contato com a borda da janela = não é um balão fechado (fundo aberto).
        if (total == 0 || border > 14) return null

        val maxRow = rowC.max()
        val maxCol = colC.max()
        var minY = -1; var maxY = -1; var minX = -1; var maxX = -1
        for (gy in 0 until gh) if (rowC[gy] >= maxRow * 0.3f) { if (minY < 0) minY = gy; maxY = gy }
        for (gx in 0 until gw) if (colC[gx] >= maxCol * 0.3f) { if (minX < 0) minX = gx; maxX = gx }
        if (minX < 0 || minY < 0) return null
        return Rect(x0 + minX * st, y0 + minY * st, x0 + (maxX + 1) * st, y0 + (maxY + 1) * st)
    }
}
