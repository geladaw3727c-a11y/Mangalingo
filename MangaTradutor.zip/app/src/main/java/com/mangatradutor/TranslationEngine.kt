package com.mangatradutor

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.tasks.await
import kotlin.math.max
import kotlin.math.min

/** Uma fala já traduzida, pronta para desenhar sobre a tela. */
class Item(val rect: RectF, val bg: Int, val layout: StaticLayout, val inner: Float)

class TranslationEngine {

    private class Cand(val box: Rect, val raw: String, val lines: Int, val score: Int)

    private val latin: TextRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val ja: TextRecognizer = TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
    private val ko: TextRecognizer = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
    private val zh: TextRecognizer = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
    private val langId = LanguageIdentification.getClient()
    private val translators = HashMap<String, Translator>()
    private val cache = HashMap<String, String>()

    fun close() {
        latin.close(); ja.close(); ko.close(); zh.close(); langId.close()
        translators.values.forEach { it.close() }
    }

    suspend fun process(bmp: Bitmap, density: Float): List<Item> = coroutineScope {
        val img = InputImage.fromBitmap(bmp, 0)
        val recs: List<Pair<Int, TextRecognizer>> = listOf(0 to latin, 1 to ja, 2 to ko, 3 to zh)

        val all: List<Cand> = recs.map { (kind, rec) ->
            async {
                try {
                    val out = ArrayList<Cand>()
                    for (b in rec.process(img).await().textBlocks) {
                        val box = b.boundingBox ?: continue
                        val s = score(kind, b.text)
                        if (s > 0) out.add(Cand(box, b.text, max(1, b.lines.size), s))
                    }
                    out
                } catch (e: Exception) {
                    ArrayList<Cand>()
                }
            }
        }.awaitAll().flatten()

        // Remove duplicatas (mesma fala lida por reconhecedores diferentes): vence o de maior pontuação.
        val kept = ArrayList<Cand>()
        for (c in all.sortedByDescending { it.score }) {
            if (kept.none { overlaps(it.box, c.box) }) kept.add(c)
        }

        val result = ArrayList<Item>()
        for (c in kept) {
            try {
                val (kana, hang, han, lat) = counts(c.raw)
                val cjk = kana + hang + han > lat
                val text = if (cjk) c.raw.replace("\n", "")
                else c.raw.replace("-\n", "").replace("\n", " ")
                if (text.trim().length < 2) continue

                val src = when {
                    kana > 0 -> "ja"
                    hang > 0 -> "ko"
                    han > 0 && lat == 0 -> {
                        val id = identify(text)
                        if (id == "ja" || id == "zh") id else "zh"
                    }
                    else -> identify(text).let { if (it == "und") "en" else it }
                }
                if (src == "pt") continue
                val tr = translate(text, src) ?: continue
                result.add(build(bmp, c.box, tr, c.lines, density))
            } catch (e: Exception) {
                // ignora a fala com problema e segue
            }
        }
        result
    }

    // ---------- idioma ----------

    private suspend fun identify(text: String): String {
        val tag = langId.identifyLanguage(text).await()
        return tag.substringBefore('-')
    }

    private fun counts(t: String): IntArray {
        var kana = 0; var hang = 0; var han = 0; var lat = 0
        for (ch in t) {
            when {
                ch in '\u3040'..'\u30FF' -> kana++
                ch in '\uAC00'..'\uD7AF' || ch in '\u1100'..'\u11FF' -> hang++
                ch in '\u4E00'..'\u9FFF' -> han++
                ch.isLetter() && ch.code < 0x250 -> lat++
            }
        }
        return intArrayOf(kana, hang, han, lat)
    }

    /** Pontuação de quanto o texto "combina" com o reconhecedor que o leu (0 = lixo). */
    private fun score(kind: Int, t: String): Int {
        val (kana, hang, han, lat) = counts(t)
        val total = kana + hang + han + lat
        if (total < 2) return 0
        return when (kind) {
            0 -> if (lat >= total * 0.8) lat else 0
            1 -> if (kana > 0 || (han > 0 && lat == 0 && hang == 0)) kana + han else 0
            2 -> if (hang >= total * 0.5) hang else 0
            else -> if (han >= total * 0.8 && kana == 0) han else 0
        }
    }

    private fun overlaps(a: Rect, b: Rect): Boolean {
        val l = max(a.left, b.left); val r = min(a.right, b.right)
        val t = max(a.top, b.top); val bt = min(a.bottom, b.bottom)
        if (r <= l || bt <= t) return false
        val inter = (r - l).toLong() * (bt - t)
        val minArea = min(a.width().toLong() * a.height(), b.width().toLong() * b.height())
        return minArea > 0 && inter > minArea * 0.3
    }

    // ---------- tradução ----------

    private suspend fun translate(text: String, src: String): String? {
        val key = "$src|$text"
        cache[key]?.let { return it }
        val lang = TranslateLanguage.fromLanguageTag(src) ?: return null
        val tr = translators.getOrPut(src) {
            Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(lang)
                    .setTargetLanguage(TranslateLanguage.PORTUGUESE)
                    .build()
            )
        }
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
        val out = tr.translate(text).await()
        cache[key] = out
        return out
    }

    // ---------- desenho: fundo, cor e tamanho ----------

    private fun build(bmp: Bitmap, box: Rect, text: String, lines: Int, d: Float): Item {
        val sw = bmp.width.toFloat()
        val sh = bmp.height.toFloat()
        val pad = max(6f, min(box.width(), box.height()) * 0.08f)
        val inner = 4f * d

        val bg = sampleBg(bmp, box, pad.toInt())
        val lum = 0.299 * Color.red(bg) + 0.587 * Color.green(bg) + 0.114 * Color.blue(bg)
        val fg = if (lum > 140) Color.rgb(17, 17, 17) else Color.rgb(242, 242, 242)

        // Tamanho: proporcional ao original, mas nunca menor que o mínimo legível.
        val origPx = box.height().toFloat() / lines * 0.8f
        val minPx = 13f * d
        val maxPx = 40f * d
        var size = origPx.coerceIn(minPx, maxPx)

        val cx = box.exactCenterX()
        val cy = box.exactCenterY()
        var w = max(box.width() + 2 * pad, 48f * d)
        var h = box.height() + 2 * pad

        val paint = TextPaint(TextPaint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.DEFAULT_BOLD
            color = fg
        }
        fun lay(sz: Float, ww: Float): StaticLayout {
            paint.textSize = sz
            return StaticLayout.Builder
                .obtain(text, 0, text.length, paint, max(10, (ww - 2 * inner).toInt()))
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setIncludePad(false)
                .setLineSpacing(0f, 0.95f)
                .build()
        }

        var layout = lay(size, w)
        while (size > minPx && layout.height > h - 2 * inner) {
            size -= 0.75f * d
            layout = lay(size, w)
        }
        if (layout.height > h - 2 * inner) {
            // Não coube no tamanho mínimo: cresce o balão (largura e depois altura).
            w = min(sw * 0.9f, w * 1.4f)
            layout = lay(size, w)
            if (layout.height > h - 2 * inner) h = layout.height + 2 * inner
        }

        val left = (cx - w / 2f).coerceIn(0f, max(0f, sw - w))
        val top = (cy - h / 2f).coerceIn(0f, max(0f, sh - h))
        return Item(RectF(left, top, left + w, top + h), bg, layout, inner)
    }

    /** Cor mais comum num anel ao redor da fala (= cor do balão). */
    private fun sampleBg(b: Bitmap, box: Rect, pad: Int): Int {
        val x0 = (box.left - pad).coerceIn(0, b.width - 1)
        val x1 = (box.right + pad).coerceIn(0, b.width - 1)
        val y0 = (box.top - pad).coerceIn(0, b.height - 1)
        val y1 = (box.bottom + pad).coerceIn(0, b.height - 1)
        val map = HashMap<Int, LongArray>()
        fun add(x: Int, y: Int) {
            val p = b.getPixel(x, y)
            val k = (((p shr 20) and 15) shl 8) or (((p shr 12) and 15) shl 4) or ((p shr 4) and 15)
            val a = map.getOrPut(k) { LongArray(4) }
            a[0] += 1L
            a[1] += ((p shr 16) and 255).toLong()
            a[2] += ((p shr 8) and 255).toLong()
            a[3] += (p and 255).toLong()
        }
        val sx = max(1, (x1 - x0) / 40)
        val sy = max(1, (y1 - y0) / 40)
        var x = x0
        while (x <= x1) { add(x, y0); add(x, y1); x += sx }
        var y = y0
        while (y <= y1) { add(x0, y); add(x1, y); y += sy }
        val best = map.values.maxByOrNull { it[0] } ?: return Color.WHITE
        return Color.rgb((best[1] / best[0]).toInt(), (best[2] / best[0]).toInt(), (best[3] / best[0]).toInt())
    }
}
