# Manga Tradutor

App Android que lê a tela, detecta o idioma das falas (japonês, coreano, chinês, inglês e outros),
traduz para português e desenha a tradução por cima do balão, com a cor do fundo do próprio balão.

- OCR: Google ML Kit (latim, japonês, coreano, chinês), tudo no aparelho
- Idioma: ML Kit Language ID
- Tradução: ML Kit Translate (offline depois de baixar os idiomas)
- Captura de tela: serviço de acessibilidade (`takeScreenshot`), uma permissão só, dada uma vez
- Requer Android 11 (API 30) ou superior

## Gerar o APK pelo GitHub (sem computador)

1. Crie um repositório no GitHub e envie o conteúdo desta pasta (ou só o arquivo .zip + o `build.yml`, veja abaixo).
2. Abra a aba **Actions** > **Gerar APK** > **Run workflow**.
3. Quando terminar (uns 5 a 8 min), abra a execução e baixe o artefato **MangaTradutor-APK**.
4. Descompacte, instale o `app-debug.apk` (permita "instalar de fontes desconhecidas").

### Truque para quem só tem o celular
No site do GitHub: **Add file > Upload files** e envie o `.zip` inteiro (não precisa extrair).
Depois **Add file > Create new file**, nome `.github/workflows/build.yml`, cole o conteúdo do `build.yml`
fornecido e faça o commit. O workflow extrai o zip sozinho e compila.

## Usar
1. Abra o app, toque em **Baixar idiomas** (Wi-Fi).
2. Toque em **Ativar tradução** e ligue o serviço de acessibilidade "Manga Tradutor".
3. Abra o leitor de mangá. Para traduzir: volte ao app e toque em ATIVAR/DESATIVAR. Não há botão flutuante.

## Ajustes rápidos (TranslationEngine.kt)
- `minPx = 13f * d`: tamanho mínimo da letra (aumente para falas pequenas ficarem maiores)
- `maxPx = 40f * d`: tamanho máximo
- `TranslatorService.kt`: `delay(450)` = intervalo entre capturas
